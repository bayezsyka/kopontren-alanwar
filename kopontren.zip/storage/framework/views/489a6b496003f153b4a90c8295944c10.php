<!-- Mobile Bottom Navigation -->
<nav class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50 md:hidden">
    <div class="grid grid-cols-5 gap-1">
        <a href="/pos" class="nav-item" data-page="pos">
            <i class="fas fa-cash-register text-xl"></i>
            <span class="text-xs mt-1">POS</span>
        </a>
        <a href="/restock" class="nav-item" data-page="restock">
            <i class="fas fa-truck-loading text-xl"></i>
            <span class="text-xs mt-1">Restock</span>
        </a>
        <a href="/items" class="nav-item" data-page="items">
            <i class="fas fa-box text-xl"></i>
            <span class="text-xs mt-1">Items</span>
        </a>
        <a href="/stock" class="nav-item" data-page="stock">
            <i class="fas fa-warehouse text-xl"></i>
            <span class="text-xs mt-1">Stock</span>
        </a>
        <a href="/owner/dashboard" class="nav-item" data-page="owner" id="ownerNavItem" style="display: none;">
            <i class="fas fa-chart-line text-xl"></i>
            <span class="text-xs mt-1">Owner</span>
        </a>
    </div>
</nav>

<!-- Desktop Sidebar Navigation -->
<nav class="hidden md:block fixed left-0 top-16 bottom-0 w-64 bg-white border-r border-gray-200 z-40">
    <div class="p-4 space-y-2">
        <a href="/pos" class="nav-link" data-page="pos">
            <i class="fas fa-cash-register w-5"></i>
            <span>Point of Sale</span>
        </a>
        <a href="/restock" class="nav-link" data-page="restock">
            <i class="fas fa-truck-loading w-5"></i>
            <span>Restock Barang</span>
        </a>
        <a href="/items" class="nav-link" data-page="items">
            <i class="fas fa-box w-5"></i>
            <span>Manajemen Item</span>
        </a>
        <a href="/stock" class="nav-link" data-page="stock">
            <i class="fas fa-warehouse w-5"></i>
            <span>Stok Barang</span>
        </a>
        <div id="ownerSidebarItem" style="display: none;">
            <div class="border-t border-gray-200 my-2"></div>
            <a href="/owner/dashboard" class="nav-link" data-page="owner">
                <i class="fas fa-chart-line w-5"></i>
                <span>Dashboard Owner</span>
            </a>
            <a href="/owner/reports" class="nav-link" data-page="reports">
                <i class="fas fa-file-alt w-5"></i>
                <span>Laporan</span>
            </a>
        </div>
    </div>
</nav>

<style>
.nav-item {
    @apply flex flex-col items-center justify-center py-3 text-gray-500 transition-colors;
}

.nav-item.active {
    @apply text-[#008362] bg-[#008362] bg-opacity-5;
}

.nav-link {
    @apply flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors;
}

.nav-link.active {
    @apply bg-[#008362] text-white;
}

.nav-link i {
    @apply text-lg;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const ownerNavItem = document.getElementById('ownerNavItem');
    const ownerSidebarItem = document.getElementById('ownerSidebarItem');
    const navItems = document.querySelectorAll('.nav-item');
    const navLinks = document.querySelectorAll('.nav-link');
    const currentPath = window.location.pathname;

    // Show owner nav for owner role
    const checkOwner = setInterval(() => {
        if (!window.authGuard.isLoading) {
            if (window.authGuard.isOwner()) {
                ownerNavItem.style.display = 'flex';
                ownerSidebarItem.style.display = 'block';
            }
            clearInterval(checkOwner);
        }
    }, 100);

    // Set active nav item (mobile)
    navItems.forEach(item => {
        const page = item.getAttribute('data-page');
        if (currentPath.includes(page) || (page === 'pos' && currentPath === '/')) {
            item.classList.add('active');
        }
    });

    // Set active nav link (desktop)
    navLinks.forEach(link => {
        const page = link.getAttribute('data-page');
        if (currentPath.includes(page) || (page === 'pos' && currentPath === '/')) {
            link.classList.add('active');
        }
    });
});
</script>
<?php /**PATH C:\Coding\Al-Anwar\kopontren\resources\views/layouts/bottom-nav.blade.php ENDPATH**/ ?>