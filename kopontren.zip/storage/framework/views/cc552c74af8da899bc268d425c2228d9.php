<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<!-- External Services -->
<script src="<?php echo e(asset('js/api-client.js')); ?>"></script>
<script src="<?php echo e(asset('js/offline-db.js')); ?>"></script>
<script src="<?php echo e(asset('js/sync-service.js')); ?>"></script>
<script src="<?php echo e(asset('js/auth-guard.js')); ?>"></script>

<script>
    // --- Global Helpers ---
    
    function formatRupiah(number) {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        }).format(number);
    }
    
    function formatNumber(number) {
        return new Intl.NumberFormat('id-ID').format(number);
    }
    
    function formatDate(dateString) {
        if (!dateString) return '-';
        return new Date(dateString).toLocaleDateString('id-ID', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }

    function showToast(message, type = 'success') {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        
        // Colors base
        let bgClass, iconClass, icon;
        
        if (type === 'error') {
            bgClass = 'bg-white border-l-4 border-red-500 text-gray-800';
            iconClass = 'text-red-500';
            icon = 'fa-exclamation-circle';
        } else if (type === 'warning') {
            bgClass = 'bg-white border-l-4 border-amber-500 text-gray-800';
            iconClass = 'text-amber-500';
            icon = 'fa-exclamation-triangle';
        } else {
            bgClass = 'bg-[#008362] text-white border-none';
            iconClass = 'text-white/80';
            icon = 'fa-check-circle';
        }

        toast.className = `${bgClass} shadow-lg rounded-r-lg p-4 flex items-center gap-3 transform translate-y-10 opacity-0 transition-all duration-300 min-w-[300px] pointer-events-auto`;
        toast.innerHTML = `
            <i class="fas ${icon} ${iconClass} text-lg"></i>
            <span class="font-medium text-sm flex-1">${message}</span>
            <button onclick="this.parentElement.remove()" class="text-current opacity-50 hover:opacity-100">
                <i class="fas fa-times"></i>
            </button>
        `;

        container.appendChild(toast);
        
        // Animate in
        requestAnimationFrame(() => {
            toast.classList.remove('translate-y-10', 'opacity-0');
        });

        // Auto remove
        setTimeout(() => {
            toast.classList.add('translate-x-full', 'opacity-0');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    function showLoading() {
        // Implement global loading overlay if needed
        // For now we assume pages handle their own loading skeletons
    }

    function hideLoading() {
        // Hide overlay
    }

    // --- Init Services ---
    document.addEventListener('DOMContentLoaded', async () => {
        // Init API Client
        window.api = new ApiClient();
        
        // Init Offline DB
        window.offlineDB = new OfflineDatabase();
        await window.offlineDB.init();
        
        // Init Auth Guard
        window.authGuard = new AuthGuard();
        await window.authGuard.init();
        
        // Init Sync Service
        window.syncService = new SyncService();
        window.syncService.init();

        console.log('Services initialized');
    });
</script>
<?php /**PATH C:\Coding\Al-Anwar\kopontren\resources\views/layouts/scripts.blade.php ENDPATH**/ ?>