<header class="bg-white sticky top-0 z-40 shadow-[0_2px_15px_-3px_rgba(0,0,0,0.07),0_10px_20px_-2px_rgba(0,0,0,0.04)] transition-all duration-300">
    <!-- Top accent line -->
    <div class="h-1 w-full bg-gradient-to-r from-[#008362] via-[#00a87e] to-[#008362]"></div>
    
    <div class="px-4 md:px-6">
        <div class="flex items-center justify-between h-16 md:h-20 max-w-7xl mx-auto">
            <!-- Brand Section -->
            <div class="flex items-center gap-4">
                <div class="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-[#008362] to-[#4ade80] text-white shadow-lg shadow-green-500/20 transform transition-transform hover:rotate-3">
                    <i class="fas fa-store text-lg"></i>
                </div>
                <div class="flex flex-col">
                    <span class="text-xl font-bold tracking-tight text-gray-900 leading-none">Kopontren</span>
                    <span class="text-[11px] font-medium text-[#008362] tracking-widest uppercase mt-1">Kasir System</span>
                </div>
            </div>

            <!-- Desktop Navigation - Centered & Clean -->
            <nav class="hidden md:flex items-center gap-2">
                <a href="/pos" class="nav-item group" data-page="pos">
                    <i class="fas fa-cash-register mb-0.5 group-hover:-translate-y-0.5 transition-transform"></i>
                    <span>POS</span>
                </a>
                <a href="/restock" class="nav-item group" data-page="restock">
                    <i class="fas fa-truck-loading mb-0.5 group-hover:-translate-y-0.5 transition-transform"></i>
                    <span>Restock</span>
                </a>
                <a href="/items" class="nav-item group" data-page="items">
                    <i class="fas fa-box mb-0.5 group-hover:-translate-y-0.5 transition-transform"></i>
                    <span>Items</span>
                </a>
                <a href="/stock" class="nav-item group" data-page="stock">
                    <i class="fas fa-warehouse mb-0.5 group-hover:-translate-y-0.5 transition-transform"></i>
                    <span>Stock</span>
                </a>

                <!-- Owner Section Divider -->
                <div id="ownerNavDesktop" style="display: none;" class="flex items-center gap-2 pl-2 ml-2 border-l-2 border-gray-100">
                    <a href="/owner/dashboard" class="nav-item group text-amber-700" data-page="owner">
                        <i class="fas fa-chart-pie mb-0.5 group-hover:-translate-y-0.5 transition-transform"></i>
                        <span>Dashboard</span>
                    </a>
                    <a href="/owner/reports" class="nav-item group text-amber-700" data-page="reports">
                        <i class="fas fa-file-invoice mb-0.5 group-hover:-translate-y-0.5 transition-transform"></i>
                        <span>Laporan</span>
                    </a>
                </div>
            </nav>

            <!-- User Profile & Actions -->
            <div class="flex items-center gap-4">
                <div class="hidden md:flex flex-col items-end mr-2">
                    <div id="userInfoName" class="text-sm font-bold text-gray-800"></div>
                    <div id="userInfoRole" class="text-[10px] text-gray-500 font-medium"></div>
                </div>

                <!-- Mode Switcher (Owner Only) -->
                <div id="modeSwitcher" style="display: none;">
                    <select id="modeSelect" class="bg-gray-50 text-xs font-semibold py-2 pl-3 pr-8 rounded-lg border-0 focus:ring-2 focus:ring-[#008362]/20 cursor-pointer hover:bg-gray-100 transition-colors">
                        <option value="kasir">View: Kasir</option>
                        <option value="owner">View: Owner</option>
                    </select>
                </div>

                <div class="h-8 w-px bg-gray-200 hidden md:block"></div>

                <button id="logoutBtn" class="group flex items-center justify-center w-10 h-10 rounded-full text-gray-400 hover:text-red-500 hover:bg-red-50 transition-all duration-300" title="Logout">
                    <i class="fas fa-power-off text-lg group-hover:scale-110 transition-transform"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile Navigation Bar (Clean Scroll) -->
    <nav class="md:hidden border-t border-gray-100 bg-white">
        <div class="flex overflow-x-auto px-4 py-3 gap-6 hide-scrollbar">
            <a href="/pos" class="mobile-nav-item" data-page="pos">
                <i class="fas fa-cash-register"></i>POS
            </a>
            <a href="/restock" class="mobile-nav-item" data-page="restock">
                <i class="fas fa-truck-loading"></i>Restock
            </a>
            <a href="/items" class="mobile-nav-item" data-page="items">
                <i class="fas fa-box"></i>Items
            </a>
            <a href="/stock" class="mobile-nav-item" data-page="stock">
                <i class="fas fa-warehouse"></i>Stock
            </a>
            <div id="ownerNavMobile" style="display: none;" class="flex gap-6 pl-6 border-l border-gray-100">
                <a href="/owner/dashboard" class="mobile-nav-item text-amber-600" data-page="owner">
                    <i class="fas fa-chart-pie"></i>Owner
                </a>
                <a href="/owner/reports" class="mobile-nav-item text-amber-600" data-page="reports">
                    <i class="fas fa-file-invoice"></i>Report
                </a>
            </div>
        </div>
    </nav>
</header>

<style>
/* Desktop Item */
.nav-item {
    @apply flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold text-gray-500 transition-all duration-300 relative overflow-hidden;
}

.nav-item::after {
    content: '';
    @apply absolute bottom-0 left-0 w-full h-0.5 bg-[#008362] opacity-0 transition-opacity duration-300;
}

.nav-item:hover {
    @apply text-[#008362] bg-[#008362]/5;
}

.nav-item.active {
    @apply text-[#008362] bg-[#008362]/10;
}
.nav-item.active::after {
    @apply opacity-100;
}

/* Mobile Item */
.mobile-nav-item {
    @apply flex flex-col items-center gap-1 text-xs font-semibold text-gray-400 whitespace-nowrap min-w-[3rem];
}
.mobile-nav-item i {
    @apply text-lg mb-1 p-2 rounded-xl transition-all duration-300;
}
.mobile-nav-item.active {
    @apply text-[#008362];
}
.mobile-nav-item.active i {
    @apply bg-[#008362] text-white shadow-md shadow-green-500/30 transform -translate-y-1;
}

/* Utils */
.hide-scrollbar::-webkit-scrollbar { display: none; }
.hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
</style>



<script>
document.addEventListener('DOMContentLoaded', () => {
    const userInfoEl = document.getElementById('userInfo');
    const modeSwitcher = document.getElementById('modeSwitcher');
    const modeSelect = document.getElementById('modeSelect');
    const logoutBtn = document.getElementById('logoutBtn');
    const ownerNavDesktop = document.getElementById('ownerNavDesktop');
    const ownerNavMobile = document.getElementById('ownerNavMobile');
    const currentPath = window.location.pathname;

    // Display user info
    function updateHeader() {
        const user = window.authGuard.getUser();
        if (user) {
            const roleBadge = user.role === 'owner' ? 
                '<span class="bg-amber-100 text-amber-800 px-2 py-0.5 rounded text-xs font-medium">Owner</span>' :
                '<span class="bg-[#008362] bg-opacity-10 text-[#008362] px-2 py-0.5 rounded text-xs font-medium">Kasir</span>';
            
            userInfoEl.innerHTML = `${user.name} ${roleBadge}`;

            // Show mode switcher and owner nav for owner
            if (user.role === 'owner') {
                modeSwitcher.style.display = 'block';
                modeSelect.value = user.ui_mode;
                ownerNavDesktop.style.display = 'flex';
                ownerNavMobile.style.display = 'flex';
            }
        }
    }

    // Set active navigation
    document.querySelectorAll('.nav-item, .mobile-nav-item').forEach(link => {
        const page = link.getAttribute('data-page');
        if (currentPath.includes(page) || (page === 'pos' && currentPath === '/')) {
            link.classList.add('active');
        }
    });

    // Mode switch handler
    modeSelect?.addEventListener('change', async (e) => {
        const newMode = e.target.value;
        await window.authGuard.switchMode(newMode);
    });

    // Logout handler
    logoutBtn?.addEventListener('click', async () => {
        if (confirm('Yakin ingin logout?')) {
            await window.api.logout();
        }
    });

    // Wait for auth guard to load
    const checkAuth = setInterval(() => {
        if (!window.authGuard.isLoading && window.authGuard.getUser()) {
            updateHeader();
            clearInterval(checkAuth);
        }
    }, 100);
});
</script>
<?php /**PATH C:\Coding\Al-Anwar\kopontren\resources\views/layouts/header.blade.php ENDPATH**/ ?>