<div id="offline-indicator" class="hidden fixed top-0 left-0 right-0 bg-amber-500 text-white py-2 px-4 text-center text-sm z-[60]">
    <i class="fas fa-wifi mr-2"></i>
    <span>Mode Offline - Data akan disinkronkan otomatis saat online</span>
</div>

<script>
function updateOnlineStatus() {
    const indicator = document.getElementById('offline-indicator');
    if (navigator.onLine) {
        indicator?.classList.add('hidden');
    } else {
        indicator?.classList.remove('hidden');
    }
}

window.addEventListener('online', updateOnlineStatus);
window.addEventListener('offline', updateOnlineStatus);
document.addEventListener('DOMContentLoaded', updateOnlineStatus);
</script>
<?php /**PATH C:\Coding\Al-Anwar\kopontren\resources\views/layouts/offline-indicator.blade.php ENDPATH**/ ?>